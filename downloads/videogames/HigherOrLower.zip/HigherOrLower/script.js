// ==================== DATI DEL GIOCO ====================
const googleTrends = [
  { name: "YouTube", value: 2450.3, image: "https://upload.wikimedia.org/wikipedia/commons/4/42/YouTube_icon_%282013-2017%29.png" },
  { name: "Facebook", value: 2198.7, image: "https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" },
  { name: "WhatsApp", value: 1902.4, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/WhatsApp_Logo_green.svg/1280px-WhatsApp_Logo_green.svg.png" },
  { name: "Instagram", value: 1798.2, image: "https://upload.wikimedia.org/wikipedia/commons/e/e7/Instagram_logo_2016.svg" },
  { name: "TikTok", value: 1705.6, image: "https://img.freepik.com/psd-premium/logo-tiktok_1131634-487.jpg?semt=ais_hybrid&w=740&q=80" },
  { name: "ChatGPT", value: 1497.3, image: "https://upload.wikimedia.org/wikipedia/commons/0/04/ChatGPT_logo.svg" },
  { name: "Amazon", value: 1302.8, image: "https://upload.wikimedia.org/wikipedia/commons/4/4a/Amazon_icon.svg" },
  { name: "Google Translate", value: 1198.4, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Google_Translate_logo.svg/960px-Google_Translate_logo.svg.png" },
  { name: "Netflix", value: 1103.9, image: "https://platform.theverge.com/wp-content/uploads/sites/2/chorus/uploads/chorus_asset/file/15844974/netflixlogo.0.0.1466448626.png?quality=90&strip=all&crop=1.2535702951444%2C0%2C97.492859409711%2C100&w=2400" },
  { name: "X (Twitter)", value: 1047.2, image: "https://upload.wikimedia.org/wikipedia/commons/c/ce/X_logo_2023.svg" },
  { name: "Google", value: 950.6, image: "https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg" },
  { name: "Spotify", value: 948.3, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Spotify_icon.svg/1280px-Spotify_icon.svg.png?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail" },
  { name: "Apple", value: 879.5, image: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg" },
  { name: "Weather", value: 897.1, image: "https://cdn.freebiesupply.com/logos/large/2x/weather-ios-logo-png-transparent.png" },
  { name: "Samsung", value: 802.4, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Samsung_old_logo_before_year_2015.svg/3840px-Samsung_old_logo_before_year_2015.svg.png" },
  { name: "CNN", value: 748.6, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/CNN.svg/1280px-CNN.svg.png" },
  { name: "BBC", value: 719.3, image: "https://cdn.prod.website-files.com/5d70d85d6d5a384776dc97e4/681a06988d6eef43be96638a_63c021b46c48feb8a33c3916.webp" },
  { name: "World Cup", value: 698.2, image: "https://upload.wikimedia.org/wikipedia/en/1/17/2026_FIFA_World_Cup_emblem.svg" },
  { name: "Olympics", value: 679.5, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Olympic_rings_without_rims.svg/1280px-Olympic_rings_without_rims.svg.png" },
  { name: "Cristiano Ronaldo", value: 653.8, image: "https://upload.wikimedia.org/wikipedia/commons/8/8c/Cristiano_Ronaldo_2018.jpg" },
  { name: "Lionel Messi", value: 641.2, image: "https://upload.wikimedia.org/wikipedia/commons/c/c1/Lionel_Messi_20180626.jpg" },
  { name: "Taylor Swift", value: 598.7, image: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Taylor_Swift_at_the_2023_MTV_Video_Music_Awards_%283%29.png" },
  { name: "Elon Musk", value: 579.4, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Elon_Musk_-_54820081119_%28cropped%29.jpg/250px-Elon_Musk_-_54820081119_%28cropped%29.jpg" },
  { name: "Donald Trump", value: 552.1, image: "https://upload.wikimedia.org/wikipedia/commons/5/56/Donald_Trump_official_portrait.jpg" },
  { name: "Joe Biden", value: 518.6, image: "https://upload.wikimedia.org/wikipedia/commons/6/68/Joe_Biden_presidential_portrait.jpg" },
  { name: "NASA", value: 499.8, image: "https://upload.wikimedia.org/wikipedia/commons/e/e5/NASA_logo.svg" },
  { name: "Tesla", value: 489.3, image: "https://upload.wikimedia.org/wikipedia/commons/b/bd/Tesla_Motors.svg" },
  { name: "Nike", value: 472.5, image: "https://upload.wikimedia.org/wikipedia/commons/a/a6/Logo_NIKE.svg" },
  { name: "Adidas", value: 451.2, image: "https://upload.wikimedia.org/wikipedia/commons/2/20/Adidas_Logo.svg" },
  { name: "McDonald's", value: 428.9, image: "https://upload.wikimedia.org/wikipedia/commons/3/36/McDonald%27s_Golden_Arches.svg" },
  { name: "Starbucks", value: 419.7, image: "https://upload.wikimedia.org/wikipedia/sco/thumb/d/d3/Starbucks_Corporation_Logo_2011.svg/1280px-Starbucks_Corporation_Logo_2011.svg.png" },
  { name: "Coca-Cola", value: 408.3, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Coca-Cola_logo.svg/960px-Coca-Cola_logo.svg.png" },
  { name: "Pepsi", value: 391.6, image: "https://upload.wikimedia.org/wikipedia/commons/0/0f/Pepsi_logo_2014.svg" },
  { name: "IKEA", value: 368.4, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Ikea_logo.svg/1280px-Ikea_logo.svg.png" },
  { name: "Disney", value: 359.2, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Disney%2B_logo.svg/3840px-Disney%2B_logo.svg.png" },
  { name: "Marvel", value: 348.7, image: "https://upload.wikimedia.org/wikipedia/commons/b/b9/Marvel_Logo.svg" },
  { name: "DC Comics", value: 331.5, image: "https://upload.wikimedia.org/wikipedia/commons/3/3d/DC_Comics_logo.svg" },
  { name: "Harry Potter", value: 322.8, image: "https://cdn.shopify.com/s/files/1/1943/7257/files/Harry-Potter_large_0dad831f-4b4a-4db5-b0eb-f96e70436102_large.jpg?v=1514443105" },
  { name: "Star Wars", value: 309.4, image: "https://upload.wikimedia.org/wikipedia/commons/6/6c/Star_Wars_Logo.svg" },
  { name: "Pokémon", value: 301.2, image: "https://upload.wikimedia.org/wikipedia/commons/9/98/International_Pok%C3%A9mon_logo.svg" },
  { name: "Minecraft", value: 291.7, image: "https://www.nintendo.com/eu/media/images/10_share_images/games_15/nintendo_switch_4/2x1_NSwitch_Minecraft.jpg" },
  { name: "Fortnite", value: 279.3, image: "https://cdn1.epicgames.com/offer/fn/FNBR_40-00_C7S2_Jules_EGS_Launcher_Blade_2560x1440_2560x1440-5dae77b5836a4d44a97f2a5d32432008" },
  { name: "GTA", value: 268.9, image: "https://gaming-cdn.com/images/products/15506/orig/grand-theft-auto-vi-playstation-5-playstation-store-cover.jpg?v=1762467710" },
  { name: "Call of Duty", value: 259.6, image: "https://gmedia.playstation.com/is/image/SIEPDC/call-of-duty-franchise-hub-keyart-01-en-21nov23?$facebook$" },
  { name: "FIFA", value: 248.2, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Flag_of_FIFA.svg/250px-Flag_of_FIFA.svg.png" },
  { name: "NBA", value: 239.5, image: "https://cdn.phenompeople.com/CareerConnectResources/NBANBAUS/social/1024x512-1670500646586.jpg" },
  { name: "NFL", value: 228.7, image: "https://loghi-famosi.com/wp-content/uploads/2021/09/NFL-Logo.png" },
  { name: "UEFA", value: 219.4, image: "https://img.uefa.com/imgml/uefacom/fallback.jpg" },
  { name: "Formula 1", value: 211.8, image: "https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/cea1/live/1de105b0-f5a5-11ef-bcea-7b70a14a5556.jpg" },
  { name: "Barbie", value: 201.3, image: "https://upload.wikimedia.org/wikipedia/commons/0/0b/Barbie_Logo.svg" },
  { name: "Oppenheimer", value: 189.6, image: "https://www.uominiedonnecomunicazione.com/wp-content/uploads/2023/09/Oppenheimer.jpg" },
  { name: "Squid Game", value: 178.4, image: "https://dnm.nflximg.net/api/v6/2DuQlx0fM4wd1nzqm5BFBi6ILa8/AAAAQVylBzU37ZpOJaV_EWOfGm7R3S6KJxdwj1KUgk7YQNg_vr7mSCnXzWJ7OaLdgqhKCGX2qeyrkWINXY_FJfoeRCsaIylCBHtQczT5GSpoHv7i0L0xCcQtXN4O8mAwzQZQqeUCXyLtVuwjlz50PCU66aV1.jpg?r=0f1" },
  { name: "Wednesday", value: 169.2, image: "https://dnm.nflximg.net/api/v6/BvVbc2Wxr2w6QuoANoSpJKEIWjQ/AAAAQcjqGozZxNBo2panMAZgMT70U-ftMvHRvpKRvXG13QuDafaDy-W7wKRl5iCpdju_BjJw0wQnKQwMdPjnP5ffHav-UnNyZRnh_lwQrWgFe8XqzdE4CY5LRMFRGxz-61vCYDFLYx5X0s2cFNEmtlYj68jX_NY.jpg?r=414" },
  { name: "Stranger Things", value: 158.7, image: "https://upload.wikimedia.org/wikipedia/commons/3/38/Stranger_Things_logo.png" },
  { name: "The Last of Us", value: 149.3, image: "https://sm.ign.com/t/ign_it/screenshot/default/tlou-p1-cover_vbuz.1280.jpg" },
  { name: "House of the Dragon", value: 139.8, image: "https://www.pennadicorvo.it/wp-content/uploads/2024/08/House-of-the-Dragon-2.webp" },
  { name: "iPhone", value: 498.2, image: "https://www.rstore.it/media/catalog/product/cache/bb5991ed8856d22ce5c275e41c5f78f9/i/p/iphone_air.jpg" },
  { name: "Samsung Galaxy", value: 447.6, image: "https://immagini.trovaprezzi.it/magazine/2024/03/Samsung-Galaxy-A.jpg" },
  { name: "PlayStation", value: 398.4, image: "https://sm.ign.com/t/ign_it/screenshot/default/playstation-store_gh29.1280.jpg" },
  { name: "Xbox", value: 379.1, image: "https://sm.pcmag.com/pcmag_au/review/x/xbox/xbox_1mgb.jpg" },
  { name: "Nintendo Switch", value: 348.5, image: "https://hd2.tudocdn.net/949484?w=824&h=494" },
  { name: "AirPods", value: 321.7, image: "https://www.apple.com/v/airpods/ae/images/overview/hero_endframe__calpooy4ucr6_large.jpg" },
  { name: "iPad", value: 299.4, image: "https://techprincess.it/wp-content/uploads/2022/10/iPad-10-prezzi-caratteristiche.webp" },
  { name: "MacBook", value: 281.2, image: "https://sixcolors.com/wp-content/uploads/2018/11/air18-bleed.jpg" },
  { name: "Google Pixel", value: 258.6, image: "https://cdn.mos.cms.futurecdn.net/v2/t:0,l:454,cw:2725,ch:2044,q:80,w:2560/NzQpjQaDkMNSdDB9W8wBGf.jpg" },
  { name: "Kylian Mbappé", value: 478.3, image: "https://upload.wikimedia.org/wikipedia/commons/1/1e/Picture_with_Mbapp%C3%A9_%28cropped%29.jpg" },
  { name: "Kim Kardashian", value: 448.9, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Kim_Kardashian_West_2014.jpg/960px-Kim_Kardashian_West_2014.jpg" },
  { name: "Beyoncé", value: 431.6, image: "https://upload.wikimedia.org/wikipedia/commons/1/17/Beyonc%C3%A9_at_The_Lion_King_European_Premiere_2019.png" },
  { name: "Drake", value: 419.2, image: "https://m.media-amazon.com/images/M/MV5BMjIwNDE2ODI5OF5BMl5BanBnXkFtZTcwMDkzMjU3NQ@@._V1_.jpg" },
  { name: "Ariana Grande", value: 408.5, image: "https://m.media-amazon.com/images/M/MV5BM2JhZWJmMDEtNTU5MS00YmQ3LTk1NjMtOGFlMjM2MjZlNjg5XkEyXkFqcGc@._V1_.jpg" },
  { name: "Justin Bieber", value: 397.8, image: "https://static.wikia.nocookie.net/singmovie/images/3/3d/JustinBieber.png/revision/latest?cb=20230224233348" },
  { name: "Selena Gomez", value: 388.4, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Selena_Gomez_at_the_2024_Golden_Globes_00002.jpg/250px-Selena_Gomez_at_the_2024_Golden_Globes_00002.jpg" },
  { name: "Neymar", value: 439.1, image: "https://images.ctfassets.net/3mv54pzvptwz/55YLwKPDnRXkqMBITRpWbC/0c2aefc04afa455c20e9ca0d209698e0/53174188191_42d4c831ae_o.jpg" },
  { name: "LeBron James", value: 351.6, image: "https://cdn.britannica.com/19/233519-050-F0604A51/LeBron-James-Los-Angeles-Lakers-Staples-Center-2019.jpg" },
  { name: "Virat Kohli", value: 342.3, image: "https://cdn.britannica.com/48/252748-050-C514EFDB/Virat-Kohli-India-celebrates-50th-century-Cricket-November-15-2023.jpg" },
  { name: "Dwayne Johnson", value: 379.5, image: "https://hips.hearstapps.com/hmg-prod/images/gettyimages-2233170886-68b723d5e2124.jpg?crop=0.6669921875xw:1xh;center,top&resize=1200:*" },
  { name: "Tom Holland", value: 368.7, image: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Tom_Holland_during_pro-am_Wentworth_golf_club_2023-2.jpg/960px-Tom_Holland_during_pro-am_Wentworth_golf_club_2023-2.jpg" },
  { name: "Zendaya", value: 359.3, image: "https://www.iodonna.it/wp-content/uploads/webp/uploads/2026/04/zendaya-euphoria-3-look-marrone-fede.jpg.webp?v=2756851" },
  { name: "Ferrari", value: 361.8, image: "https://upload.wikimedia.org/wikipedia/it/thumb/5/59/Logo_della_Scuderia_Ferrari_%28vecchio%29.svg/1920px-Logo_della_Scuderia_Ferrari_%28vecchio%29.svg.png?utm_source=it.wikipedia.org&utm_campaign=index&utm_content=thumbnail" },
  { name: "Lamborghini", value: 349.2, image: "https://www.lambocars.com/wp-content/uploads/2023/08/Lamborghini-Logo-1998-present-700x394-1.png" }
];

const populationData = [
  { name: "China", value: 1425.7, image: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Flag_of_the_People%27s_Republic_of_China.svg" },
  { name: "India", value: 1428.6, image: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { name: "United States", value: 340.0, image: "https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg" },
  { name: "Indonesia", value: 277.5, image: "https://upload.wikimedia.org/wikipedia/commons/9/9f/Flag_of_Indonesia.svg" },
  { name: "Pakistan", value: 240.5, image: "https://upload.wikimedia.org/wikipedia/commons/3/32/Flag_of_Pakistan.svg" },
  { name: "Nigeria", value: 223.8, image: "https://upload.wikimedia.org/wikipedia/commons/7/79/Flag_of_Nigeria.svg" },
  { name: "Brazil", value: 216.4, image: "https://upload.wikimedia.org/wikipedia/commons/0/05/Flag_of_Brazil.svg" },
  { name: "Bangladesh", value: 173.0, image: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Flag_of_Bangladesh.svg" },
  { name: "Russia", value: 144.4, image: "https://upload.wikimedia.org/wikipedia/commons/f/f3/Flag_of_Russia.svg" },
  { name: "Mexico", value: 128.5, image: "https://upload.wikimedia.org/wikipedia/commons/f/fc/Flag_of_Mexico.svg" },
  { name: "Japan", value: 123.3, image: "https://upload.wikimedia.org/wikipedia/commons/9/9e/Flag_of_Japan.svg" },
  { name: "Philippines", value: 117.3, image: "https://upload.wikimedia.org/wikipedia/commons/9/99/Flag_of_Philippines.svg" },
  { name: "Ethiopia", value: 126.5, image: "https://upload.wikimedia.org/wikipedia/commons/7/71/Flag_of_Ethiopia.svg" },
  { name: "Egypt", value: 112.7, image: "https://upload.wikimedia.org/wikipedia/commons/f/fe/Flag_of_Egypt.svg" },
  { name: "Vietnam", value: 98.9, image: "https://upload.wikimedia.org/wikipedia/commons/2/21/Flag_of_Vietnam.svg" },
  { name: "DR Congo", value: 102.3, image: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Flag_of_the_Democratic_Republic_of_the_Congo.svg" },
  { name: "Turkey", value: 85.8, image: "https://upload.wikimedia.org/wikipedia/commons/b/b4/Flag_of_Turkey.svg" },
  { name: "Iran", value: 89.2, image: "https://upload.wikimedia.org/wikipedia/commons/c/ca/Flag_of_Iran.svg" },
  { name: "Germany", value: 83.3, image: "https://upload.wikimedia.org/wikipedia/commons/b/ba/Flag_of_Germany.svg" },
  { name: "France", value: 64.8, image: "https://upload.wikimedia.org/wikipedia/commons/c/c3/Flag_of_France.svg" },
  { name: "United Kingdom", value: 67.7, image: "https://upload.wikimedia.org/wikipedia/commons/a/a5/Flag_of_the_United_Kingdom.svg" },
  { name: "Italy", value: 58.9, image: "https://upload.wikimedia.org/wikipedia/commons/0/03/Flag_of_Italy.svg" },
  { name: "South Africa", value: 60.4, image: "https://upload.wikimedia.org/wikipedia/commons/a/af/Flag_of_South_Africa.svg" },
  { name: "South Korea", value: 51.8, image: "https://upload.wikimedia.org/wikipedia/commons/0/09/Flag_of_South_Korea.svg" },
  { name: "Colombia", value: 52.1, image: "https://upload.wikimedia.org/wikipedia/commons/2/21/Flag_of_Colombia.svg" },
  { name: "Spain", value: 47.5, image: "https://upload.wikimedia.org/wikipedia/commons/9/9a/Flag_of_Spain.svg" },
  { name: "Argentina", value: 45.8, image: "https://upload.wikimedia.org/wikipedia/commons/1/1a/Flag_of_Argentina.svg" },
  { name: "Algeria", value: 45.6, image: "https://upload.wikimedia.org/wikipedia/commons/7/77/Flag_of_Algeria.svg" },
  { name: "Iraq", value: 45.5, image: "https://upload.wikimedia.org/wikipedia/commons/f/f6/Flag_of_Iraq.svg" },
  { name: "Canada", value: 38.8, image: "https://upload.wikimedia.org/wikipedia/commons/d/d9/Flag_of_Canada.svg" },
  { name: "Poland", value: 41.0, image: "https://upload.wikimedia.org/wikipedia/commons/1/12/Flag_of_Poland.svg" },
  { name: "Morocco", value: 37.8, image: "https://upload.wikimedia.org/wikipedia/commons/2/2c/Flag_of_Morocco.svg" },
  { name: "Saudi Arabia", value: 36.9, image: "https://upload.wikimedia.org/wikipedia/commons/0/0d/Flag_of_Saudi_Arabia.svg" },
  { name: "Ukraine", value: 38.0, image: "https://upload.wikimedia.org/wikipedia/commons/4/49/Flag_of_Ukraine.svg" },
  { name: "Angola", value: 36.7, image: "https://upload.wikimedia.org/wikipedia/commons/9/9d/Flag_of_Angola.svg" },
  { name: "Uzbekistan", value: 35.2, image: "https://upload.wikimedia.org/wikipedia/commons/8/84/Flag_of_Uzbekistan.svg" },
  { name: "Yemen", value: 34.4, image: "https://upload.wikimedia.org/wikipedia/commons/8/89/Flag_of_Yemen.svg" },
  { name: "Peru", value: 34.4, image: "https://upload.wikimedia.org/wikipedia/commons/c/cf/Flag_of_Peru.svg" },
  { name: "Malaysia", value: 34.3, image: "https://upload.wikimedia.org/wikipedia/commons/6/66/Flag_of_Malaysia.svg" },
  { name: "Ghana", value: 34.1, image: "https://upload.wikimedia.org/wikipedia/commons/1/19/Flag_of_Ghana.svg" },
  { name: "Mozambique", value: 33.9, image: "https://upload.wikimedia.org/wikipedia/commons/d/d0/Flag_of_Mozambique.svg" },
  { name: "Nepal", value: 30.9, image: "https://upload.wikimedia.org/wikipedia/commons/9/9b/Flag_of_Nepal.svg" },
  { name: "Madagascar", value: 30.3, image: "https://upload.wikimedia.org/wikipedia/commons/b/bc/Flag_of_Madagascar.svg" },
  { name: "Ivory Coast", value: 28.9, image: "https://upload.wikimedia.org/wikipedia/commons/8/85/Flag_of_C%C3%B4te_d%27Ivoire.svg" },
  { name: "Venezuela", value: 28.8, image: "https://upload.wikimedia.org/wikipedia/commons/0/06/Flag_of_Venezuela.svg" },
  { name: "Cameroon", value: 28.6, image: "https://upload.wikimedia.org/wikipedia/commons/4/4f/Flag_of_Cameroon.svg" },
  { name: "Niger", value: 27.2, image: "https://upload.wikimedia.org/wikipedia/commons/f/f4/Flag_of_Niger.svg" },
  { name: "Australia", value: 26.4, image: "https://upload.wikimedia.org/wikipedia/commons/8/88/Flag_of_Australia.svg" },
  { name: "North Korea", value: 26.2, image: "https://upload.wikimedia.org/wikipedia/commons/5/51/Flag_of_North_Korea.svg" },
  { name: "Taiwan", value: 23.9, image: "https://upload.wikimedia.org/wikipedia/commons/7/72/Flag_of_the_Republic_of_China.svg" }
];

const countriesArea = [
  { name: "Russia", value: 17098.2, image: "https://upload.wikimedia.org/wikipedia/commons/f/f3/Flag_of_Russia.svg" },
  { name: "Canada", value: 9984.7, image: "https://upload.wikimedia.org/wikipedia/commons/d/d9/Flag_of_Canada.svg" },
  { name: "United States", value: 9833.5, image: "https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg" },
  { name: "China", value: 9596.9, image: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Flag_of_the_People%27s_Republic_of_China.svg" },
  { name: "Brazil", value: 8515.8, image: "https://upload.wikimedia.org/wikipedia/commons/0/05/Flag_of_Brazil.svg" },
  { name: "Australia", value: 7692.0, image: "https://upload.wikimedia.org/wikipedia/commons/8/88/Flag_of_Australia.svg" },
  { name: "India", value: 3287.3, image: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { name: "Argentina", value: 2780.4, image: "https://upload.wikimedia.org/wikipedia/commons/1/1a/Flag_of_Argentina.svg" },
  { name: "Kazakhstan", value: 2724.9, image: "https://upload.wikimedia.org/wikipedia/commons/d/d3/Flag_of_Kazakhstan.svg" },
  { name: "Algeria", value: 2381.7, image: "https://upload.wikimedia.org/wikipedia/commons/7/77/Flag_of_Algeria.svg" },
  { name: "DR Congo", value: 2344.9, image: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Flag_of_the_Democratic_Republic_of_the_Congo.svg" },
  { name: "Greenland", value: 2166.1, image: "https://upload.wikimedia.org/wikipedia/commons/0/09/Flag_of_Greenland.svg" },
  { name: "Saudi Arabia", value: 2149.7, image: "https://upload.wikimedia.org/wikipedia/commons/0/0d/Flag_of_Saudi_Arabia.svg" },
  { name: "Mexico", value: 1964.4, image: "https://upload.wikimedia.org/wikipedia/commons/f/fc/Flag_of_Mexico.svg" },
  { name: "Indonesia", value: 1904.6, image: "https://upload.wikimedia.org/wikipedia/commons/9/9f/Flag_of_Indonesia.svg" },
  { name: "Sudan", value: 1861.5, image: "https://upload.wikimedia.org/wikipedia/commons/0/01/Flag_of_Sudan.svg" },
  { name: "Libya", value: 1759.5, image: "https://upload.wikimedia.org/wikipedia/commons/0/05/Flag_of_Libya.svg" },
  { name: "Iran", value: 1648.2, image: "https://upload.wikimedia.org/wikipedia/commons/c/ca/Flag_of_Iran.svg" },
  { name: "Mongolia", value: 1564.1, image: "https://upload.wikimedia.org/wikipedia/commons/4/4c/Flag_of_Mongolia.svg" },
  { name: "Peru", value: 1285.2, image: "https://upload.wikimedia.org/wikipedia/commons/c/cf/Flag_of_Peru.svg" },
  { name: "Chad", value: 1284.0, image: "https://upload.wikimedia.org/wikipedia/commons/4/4b/Flag_of_Chad.svg" },
  { name: "Niger", value: 1267.0, image: "https://upload.wikimedia.org/wikipedia/commons/f/f4/Flag_of_Niger.svg" },
  { name: "Angola", value: 1246.7, image: "https://upload.wikimedia.org/wikipedia/commons/9/9d/Flag_of_Angola.svg" },
  { name: "Mali", value: 1240.2, image: "https://upload.wikimedia.org/wikipedia/commons/9/92/Flag_of_Mali.svg" },
  { name: "South Africa", value: 1221.0, image: "https://upload.wikimedia.org/wikipedia/commons/a/af/Flag_of_South_Africa.svg" },
  { name: "Colombia", value: 1141.7, image: "https://upload.wikimedia.org/wikipedia/commons/2/21/Flag_of_Colombia.svg" },
  { name: "Ethiopia", value: 1104.3, image: "https://upload.wikimedia.org/wikipedia/commons/7/71/Flag_of_Ethiopia.svg" },
  { name: "Bolivia", value: 1098.6, image: "https://upload.wikimedia.org/wikipedia/commons/4/48/Flag_of_Bolivia.svg" },
  { name: "Mauritania", value: 1030.7, image: "https://upload.wikimedia.org/wikipedia/commons/4/43/Flag_of_Mauritania.svg" },
  { name: "Egypt", value: 1010.4, image: "https://upload.wikimedia.org/wikipedia/commons/f/fe/Flag_of_Egypt.svg" },
  { name: "Tanzania", value: 947.3, image: "https://upload.wikimedia.org/wikipedia/commons/3/38/Flag_of_Tanzania.svg" },
  { name: "Nigeria", value: 923.8, image: "https://upload.wikimedia.org/wikipedia/commons/7/79/Flag_of_Nigeria.svg" },
  { name: "Venezuela", value: 916.4, image: "https://upload.wikimedia.org/wikipedia/commons/0/06/Flag_of_Venezuela.svg" },
  { name: "Pakistan", value: 881.9, image: "https://upload.wikimedia.org/wikipedia/commons/3/32/Flag_of_Pakistan.svg" },
  { name: "Namibia", value: 825.6, image: "https://upload.wikimedia.org/wikipedia/commons/0/00/Flag_of_Namibia.svg" },
  { name: "Mozambique", value: 801.6, image: "https://upload.wikimedia.org/wikipedia/commons/d/d0/Flag_of_Mozambique.svg" },
  { name: "Turkey", value: 783.6, image: "https://upload.wikimedia.org/wikipedia/commons/b/b4/Flag_of_Turkey.svg" },
  { name: "Chile", value: 756.1, image: "https://upload.wikimedia.org/wikipedia/commons/7/85/Flag_of_Chile.svg" },
  { name: "Zambia", value: 752.6, image: "https://upload.wikimedia.org/wikipedia/commons/0/06/Flag_of_Zambia.svg" },
  { name: "Myanmar", value: 676.6, image: "https://upload.wikimedia.org/wikipedia/commons/8/8c/Flag_of_Myanmar.svg" },
  { name: "Afghanistan", value: 652.9, image: "https://upload.wikimedia.org/wikipedia/commons/5/5c/Flag_of_the_Taliban.svg" },
  { name: "South Sudan", value: 644.3, image: "https://upload.wikimedia.org/wikipedia/commons/7/7a/Flag_of_South_Sudan.svg" },
  { name: "France", value: 643.8, image: "https://upload.wikimedia.org/wikipedia/commons/c/c3/Flag_of_France.svg" },
  { name: "Somalia", value: 637.7, image: "https://upload.wikimedia.org/wikipedia/commons/a/a0/Flag_of_Somalia.svg" },
  { name: "Central African Republic", value: 623.0, image: "https://upload.wikimedia.org/wikipedia/commons/6/6f/Flag_of_the_Central_African_Republic.svg" },
  { name: "Ukraine", value: 603.5, image: "https://upload.wikimedia.org/wikipedia/commons/4/49/Flag_of_Ukraine.svg" },
  { name: "Madagascar", value: 587.0, image: "https://upload.wikimedia.org/wikipedia/commons/b/bc/Flag_of_Madagascar.svg" },
  { name: "Botswana", value: 581.7, image: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Flag_of_Botswana.svg" },
  { name: "Kenya", value: 580.4, image: "https://upload.wikimedia.org/wikipedia/commons/4/49/Flag_of_Kenya.svg" },
  { name: "Yemen", value: 528.0, image: "https://upload.wikimedia.org/wikipedia/commons/8/89/Flag_of_Yemen.svg" }
];

const spaceMass = [
  { name: "The Sun", value: 1.989e30, image: "https://images-assets.nasa.gov/image/GSFC_20171208_Archive_e001435/GSFC_20171208_Archive_e001435~orig.jpg" },
  { name: "Jupiter", value: 1.898e27, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA02873.jpg" },
  { name: "Saturn", value: 5.683e26, image: "https://solarsystem.nasa.gov/system/resources/detail_files/2490_stsci-h-p1943a-m-1440x1080.png" },
  { name: "Neptune", value: 1.024e26, image: "https://solarsystem.nasa.gov/system/stellar_items/image_files/90_neptune.jpg" },
  { name: "Uranus", value: 8.681e25, image: "https://solarsystem.nasa.gov/system/stellar_items/image_files/88_uranus.jpg" },
  { name: "The Earth", value: 5.972e24, image: "https://upload.wikimedia.org/wikipedia/commons/9/97/The_Earth_seen_from_Apollo_17.jpg" },
  { name: "Venus", value: 4.867e24, image: "https://solarsystem.nasa.gov/system/downloadable_items/1082_PIA00104_720.jpg" },
  { name: "Mars", value: 6.390e23, image: "https://solarsystem.nasa.gov/system/stellar_items/image_files/6_mars.jpg" },
  { name: "Mercury", value: 3.285e23, image: "https://solarsystem.nasa.gov/system/stellar_items/image_files/2_mercury.jpg" },
  { name: "The Moon", value: 7.342e22, image: "https://images-assets.nasa.gov/image/as11-44-6667/as11-44-6667~orig.jpg" },
  { name: "Pluto", value: 1.303e22, image: "https://solarsystem.nasa.gov/system/stellar_items/image_files/99_pluto.jpg" },
  { name: "Eris", value: 1.660e22, image: "https://solarsystem.nasa.gov/system/internal_resources/details/original/615_eris_art.jpg" },
  { name: "Haumea", value: 4.006e21, image: "https://solarsystem.nasa.gov/system/internal_resources/details/original/616_haumea_art.jpg" },
  { name: "Makemake", value: 3.100e21, image: "https://solarsystem.nasa.gov/system/internal_resources/details/original/617_makemake_art.jpg" },
  { name: "Ceres", value: 9.393e20, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA19315.jpg" },
  { name: "Pallas", value: 2.060e20, image: "https://upload.wikimedia.org/wikipedia/commons/d/d4/Pallas_Hubble.jpg" },
  { name: "Vesta", value: 2.590e20, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA14313.jpg" },
  { name: "Hygiea", value: 8.670e19, image: "https://upload.wikimedia.org/wikipedia/commons/f/fb/Hygiea_ESO.jpg" },
  { name: "Interamnia", value: 3.300e19, image: "https://upload.wikimedia.org/wikipedia/commons/1/19/Spacer.gif" },
  { name: "Davida", value: 4.380e19, image: "https://upload.wikimedia.org/wikipedia/commons/1/19/Spacer.gif" },
  { name: "Europa (Moon)", value: 4.800e22, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA00502.jpg" },
  { name: "Ganymede (Moon)", value: 1.481e23, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA00308.jpg" },
  { name: "Callisto (Moon)", value: 1.076e23, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA03456.jpg" },
  { name: "Titan (Moon)", value: 1.345e23, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA23869.jpg" },
  { name: "Triton (Moon)", value: 2.140e22, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA00317.jpg" },
  { name: "Enceladus (Moon)", value: 1.080e20, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA17202.jpg" },
  { name: "Mimas (Moon)", value: 3.750e19, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA12568.jpg" },
  { name: "Iapetus (Moon)", value: 1.800e20, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA06166.jpg" },
  { name: "Dione (Moon)", value: 1.095e21, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA07632.jpg" },
  { name: "Tethys (Moon)", value: 6.174e20, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA07738.jpg" },
  { name: "Phobos (Mars)", value: 1.066e16, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA10368.jpg" },
  { name: "Deimos (Mars)", value: 1.476e15, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA04746.jpg" },
  { name: "Halley's Comet", value: 2.200e14, image: "https://images-assets.nasa.gov/image/GPN-2000-001147/GPN-2000-001147~orig.jpg" },
  { name: "Churyumov-Gerasimenko", value: 1.000e13, image: "https://www.esa.int/var/esa/storage/images/esa_multimedia/images/2015/04/comet_on_25_march_2015_navcam/15361099-1-eng-GB/Comet_on_25_march_2015_NavCam_pillars.jpg" },
  { name: "International Space Station", value: 420000, image: "https://images-assets.nasa.gov/image/jsc2021e018698/jsc2021e018698~orig.jpg" },
  { name: "Saturn V Rocket", value: 2970000, image: "https://images-assets.nasa.gov/image/KSC-69PC-442/KSC-69PC-442~orig.jpg" },
  { name: "The Great Pyramid", value: 6e9, image: "https://upload.wikimedia.org/wikipedia/commons/e/e3/Kheops-Great_Pyramid.jpg" },
  { name: "Chicxulub Asteroid", value: 1e15, image: "https://img.asiatimes.com/wp-content/uploads/2020/06/Chicxulub-impactor-scaled.jpg" },
  { name: "Charon (Pluto)", value: 1.586e21, image: "https://photojournal.jpl.nasa.gov/jpeg/PIA19967.jpg" },
  { name: "Pholus (Centaur)", value: 3.100e17, image: "https://upload.wikimedia.org/wikipedia/commons/1/19/Spacer.gif" }
];


// ==================== STATO DEL GIOCO ====================
let currentGameMode = 'classic'; 
let currentCategory = 'google';  
let currentDataset = [];         
let itemA = null;                
let itemB = null;                
let score = 0;                   
let isTransitioning = false;     

// Gestione Pivot (Timer)
let pivotDuration = 60;          
let pivotTimeLeft = 60;          
let pivotTimerInterval = null;   

// Record personali salvati localmente
let records = {
  classic: { google: 0, population: 0, countries: 0, space: 0 },
  pivot: { google: 0, population: 0, countries: 0, space: 0 }
};

// Inizializzazione pagina e caricamento record
document.addEventListener("DOMContentLoaded", () => {
    loadRecords();
    initTheme();
    renderRecordsTable();
});


// ==================== DISPACCIO SCHERMATE ====================
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(screenId).classList.add('active');
}

function selectMode(mode) {
    currentGameMode = mode;
    showScreen('categorySelection');
    
    // Aggiorna etichetta modalità nella UI
    const title = document.getElementById('modeTitle');
    title.innerText = (mode === 'classic') ? "🎯 Classic Mode" : "⏱️ Pivot Mode (1 min)";
}

function selectCategory(category) {
    currentCategory = category;
    
    // Associa dataset e testo categoria
    let catLabel = "";
    if(category === 'google') { currentDataset = googleTrends; catLabel = "Google Trends (Millions)"; }
    else if(category === 'population') { currentDataset = populationData; catLabel = "Population (Millions)"; }
    else if(category === 'countries') { currentDataset = countriesArea; catLabel = "Country Area (thousands of km²)"; }
    else if(category === 'space') { currentDataset = spaceMass; catLabel = "Object Mass (kg)"; }
    
    document.getElementById('categoryName').innerText = catLabel;
    
    startGame();
}

function goToMainMenu() {
    stopPivotTimer();
    renderRecordsTable();
    showScreen('mainMenu');
}


// ==================== LOGICA DI GIOCO ====================
function startGame() {
    score = 0;
    isTransitioning = false;
    document.getElementById('scoreDisplay').innerText = score;
    document.getElementById('resultMessage').innerText = "";
    document.getElementById('resultMessage').className = "result-message";
    
    // Ripristina l'interfaccia iniziale del divisore VS
    const vsCircle = document.querySelector('.vs-circle');
    const vsContent = document.getElementById('vsContent');
    vsContent.innerText = "VS";
    vsContent.className = "";
    
    // Estrae i primi due elementi casuali diversi
    let idxA = Math.floor(Math.random() * currentDataset.length);
    let idxB = Math.floor(Math.random() * currentDataset.length);
    while(idxB === idxA) {
        idxB = Math.floor(Math.random() * currentDataset.length);
    }
    
    itemA = currentDataset[idxA];
    itemB = currentDataset[idxB];
    
    renderCards();
    showScreen('gameScreen');
    
    // Se modalità a tempo, avvia il timer
    if (currentGameMode === 'pivot') {
        startPivotTimer();
    }
}

function renderCards() {
    // Configura Carta A
    document.getElementById('nameA').innerText = itemA.name;
    document.getElementById('valueA').innerText = formatValue(itemA.value, currentCategory);
    document.getElementById('imgA').style.backgroundImage = `url('${itemA.image}')`;
    
    // Configura Carta B (Nascosta)
    document.getElementById('nameB').innerText = itemB.name;
    const valBEl = document.getElementById('valueB');
    valBEl.innerText = "???";
    valBEl.classList.add('hidden-value');
    document.getElementById('imgB').style.backgroundImage = `url('${itemB.image}')`;
    
    // Riabilita i pulsanti di scelta
    document.getElementById('btnHigher').disabled = false;
    document.getElementById('btnLower').disabled = false;
}

function makeGuess(guess) {
    if(isTransitioning) return;
    isTransitioning = true;
    
    // Disabilita pulsanti durante l'animazione / risposta
    document.getElementById('btnHigher').disabled = true;
    document.getElementById('btnLower').disabled = true;
    
    // Rivela il valore della Carta B
    const valBEl = document.getElementById('valueB');
    valBEl.innerText = formatValue(itemB.value, currentCategory);
    valBEl.classList.remove('hidden-value');
    
    const correct = (guess === 'higher' && itemB.value >= itemA.value) || 
                    (guess === 'lower' && itemB.value <= itemA.value);
                    
    const resMessage = document.getElementById('resultMessage');
    
    if(correct) {
        score++;
        document.getElementById('scoreDisplay').innerText = score;
        resMessage.innerText = "Correct! 🎉";
        resMessage.className = "result-message correct";
        
        // Passa alla prossima coppia dopo 1.8 secondi
        setTimeout(() => {
            setupNextTurn();
        }, 1800);
    } else {
        resMessage.innerText = "Wrong! ❌";
        resMessage.className = "result-message wrong";
        
        // In modalità classica si perde subito
        if (currentGameMode === 'classic') {
            setTimeout(() => {
                endGame(false); // Fine per errore
            }, 1800);
        } else {
            // In Pivot si continua accumulando l'errore ma senza punti, si va avanti
            setTimeout(() => {
                setupNextTurn();
            }, 1800);
        }
    }
}

function setupNextTurn() {
    document.getElementById('resultMessage').innerText = "";
    document.getElementById('resultMessage').className = "result-message";
    
    // La vecchia carta B diventa la nuova carta A
    itemA = itemB;
    
    // Trova una nuova carta B che sia diversa dalla nuova carta A
    let nextIdx = Math.floor(Math.random() * currentDataset.length);
    while(currentDataset[nextIdx].name === itemA.name) {
        nextIdx = Math.floor(Math.random() * currentDataset.length);
    }
    itemB = currentDataset[nextIdx];
    
    isTransitioning = false;
    renderCards();
}

function quitGame() {
    if(confirm("Are you sure you want to quit the current game?")) {
        goToMainMenu();
    }
}


// ==================== GESTIONE TIMING (PIVOT) ====================
function startPivotTimer() {
    stopPivotTimer(); // Sicurezza
    pivotTimeLeft = pivotDuration;
    
    const vsContent = document.getElementById('vsContent');
    vsContent.classList.add('timer-active');
    vsContent.innerText = pivotTimeLeft + "s";
    
    pivotTimerInterval = setInterval(() => {
        pivotTimeLeft--;
        if(pivotTimeLeft <= 0) {
            vsContent.innerText = "0s";
            clearInterval(pivotTimerInterval);
            endGame(true); // Fine per tempo scaduto
        } else {
            vsContent.innerText = pivotTimeLeft + "s";
        }
    }, 1000);
}

function stopPivotTimer() {
    if(pivotTimerInterval) {
        clearInterval(pivotTimerInterval);
        pivotTimerInterval = null;
    }
}

function endGame(timeExpired = false) {
    stopPivotTimer();
    
    const isNewRecord = score > records[currentGameMode][currentCategory];
    if(isNewRecord) {
        records[currentGameMode][currentCategory] = score;
        saveRecords();
    }
    
    // Prepara messaggio di Game Over
    let msg = "";
    if (currentGameMode === 'pivot' && timeExpired) {
        msg = "⏰ Time's up! You did a great job.";
    } else {
        msg = "💥 Oops, that choice was wrong!";
    }
    
    document.getElementById('gameOverMessage').innerText = msg;
    document.getElementById('finalScore').innerText = `Score: ${score}`;
    document.getElementById('newRecordBadge').style.display = isNewRecord ? "block" : "none";
    
    showScreen('gameOverScreen');
}

function restartGame() {
    startGame();
}


// ==================== FORMATTAZIONE DATI ====================
function formatValue(val, category) {
    switch(category) {
        case 'google':
            return val.toLocaleString('it-IT') + ' M';
        case 'population':
            if (val < 1) {
                const migliaia = val * 1000;
                return migliaia.toLocaleString('it-IT', { maximumFractionDigits: 0 }) + ' thousands';
            } else if (val >= 1000) {
                const billions = val / 1000;
                return billions.toLocaleString('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 3 }) + ' billions';
            } else {
                return val.toLocaleString('it-IT', { minimumFractionDigits: 0, maximumFractionDigits: 1 }) + ' millions';
            }
        case 'countries':
            const km2 = val * 1000;
            return km2.toLocaleString('it-IT') + ' km²';
        case 'space':
            let actualKg = val;
            if (actualKg === 0) return '0 kg';
            let exp = Math.floor(Math.log10(actualKg));
            let mantissa = actualKg / Math.pow(10, exp);
            let mantissaStr = mantissa.toFixed(3).replace('.', ',');
            return mantissaStr + '×10' + superscript(exp) + ' kg';
        default:
            return val.toString();
    }
}

function superscript(n) {
    const supers = '⁰¹²³⁴⁵⁶⁷⁸⁹';
    return String(n).split('').map(c => supers[c] || c).join('');
}


// ==================== GESTIONE RECORD / LOCALSTORAGE ====================
function loadRecords() {
    const saved = localStorage.getItem('higher_lower_records_v2');
    if(saved) {
        try {
            records = JSON.parse(saved);
        } catch(e) {
            console.error("Errore nel parse dei record:", e);
        }
    }
}

function saveRecords() {
    localStorage.setItem('higher_lower_records_v2', JSON.stringify(records));
}

function renderRecordsTable() {
    const listContainer = document.getElementById('recordsList');
    
    let html = `
        <table class="records-table">
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Classic Mode</th>
                    <th>Pivot Mode</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>🌐 Google Trends</td>
                    <td>${records.classic.google}</td>
                    <td>${records.pivot.google}</td>
                </tr>
                <tr>
                    <td>👥 Population</td>
                    <td>${records.classic.population}</td>
                    <td>${records.pivot.population}</td>
                </tr>
                <tr>
                    <td>🗺️ Country Area</td>
                    <td>${records.classic.countries}</td>
                    <td>${records.pivot.countries}</td>
                </tr>
                <tr>
                    <td>🚀 Object Mass (Space)</td>
                    <td>${records.classic.space}</td>
                    <td>${records.pivot.space}</td>
                </tr>
            </tbody>
        </table>
    `;
    listContainer.innerHTML = html;
}


// ==================== CAMBIO TEMA (LIGHT/DARK) ====================
function initTheme() {
    const toggleBtn = document.getElementById('themeToggle');
    const savedTheme = localStorage.getItem('higher_lower_theme') || 'light';
    
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    toggleBtn.addEventListener('click', () => {
        let currentTheme = document.documentElement.getAttribute('data-theme');
        let newTheme = (currentTheme === 'dark') ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('higher_lower_theme', newTheme);
    });
}